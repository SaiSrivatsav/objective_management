sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("mboapproval.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map